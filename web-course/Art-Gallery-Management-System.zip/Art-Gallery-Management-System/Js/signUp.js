const video = document.getElementById('video');
let playbackPosition = 0;

video.addEventListener('timeupdate', function() {
    playbackPosition = video.currentTime;
});

window.addEventListener('beforeunload', function() {
    localStorage.setItem('videoPlaybackPosition', playbackPosition);
});

window.addEventListener('load', function() {
    const storedPosition = localStorage.getItem('videoPlaybackPosition');
    if (storedPosition) {
        video.currentTime = parseFloat(storedPosition);
    }
});
