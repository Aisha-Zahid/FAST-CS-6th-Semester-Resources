const video = document.getElementById('video');
let playbackPosition = 0;

video.addEventListener('timeupdate', function() {
    playbackPosition = video.currentTime;
});

window.addEventListener('beforeunload', function() {
    localStorage.setItem('videoPlaybackPosition', playbackPosition);
});

window.addEventListener('load', function() {
    const storedPosition = localStorage.getItem('videoPlaybackPosition');
    if (storedPosition) {
        video.currentTime = parseFloat(storedPosition);
    }
});

const username = document.getElementById('username');
const password = document.getElementById('password');
const form = document.getElementById('form');

form.addEventListener('submit', function(e) {
    let messages = [];

    e.preventDefault();
    if (username.value.trim() === '') {
        messages.push('Username is required');
    }

    if (password.value.trim() === '') {
        messages.push('Password is required');
    }

   
    if (messages.length > 0) {
        alert(messages.join('\n'));
    } else {
        form.submit();
    }
});

